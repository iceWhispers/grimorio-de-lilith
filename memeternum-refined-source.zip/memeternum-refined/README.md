# ∅ memeternum ∞ | digital grimoire

> *"Entre algoritmos e abismos, uma voz se levantou."*

Um site artístico interativo que explora a tensão entre ordem e caos, expressando personalidade através de números, símbolos, cores e a manifestação do tédio como força criativa.

## 🎨 Conceito Artístico

### Filosofia Central
**"O Tédio como Vilão Ativo"** - Uma força que não apenas existe, mas que ativamente gera confusão, transformação e caos criativo.

### Elementos Visuais
- **Números Flutuantes**: Sequências matemáticas (Pi, Fibonacci, números primos) em movimento constante
- **Símbolos Orbitais**: Elementos alquímicos (∞, Δ, Ψ, ⚡, 🜃) que orbitam o cursor
- **Matrix Rain**: Chuva de código com símbolos personalizados
- **Geometria Sagrada**: Padrões fractais que respiram no fundo
- **Partículas Interativas**: Sistema que reage ao movimento do mouse

## 🚀 Funcionalidades

### Sistema BOREDOM.exe
- Medidor de tédio que cresce com o tempo
- Efeitos de glitch quando atinge o máximo
- Distorção visual progressiva
- Fragmentação de texto

### Navegação Simbólica
- **∅ VOID**: O vazio antes da criação
- **∞ LOOPS**: Ciclos infinitos de existência digital
- **Δ CHAOS**: Transformações criativas nascidas do tédio
- **Ψ MIND**: Fluxos de consciência em código
- **⚡ GLITCH**: Interferências na comunicação

### Áudio Ambiente
- Sons adaptativos baseados na seção atual
- Frequências que mudam com o nível de tédio
- Efeitos de glitch sonoro
- Controle de ativação pelo usuário

### Otimizações Inteligentes
- Detecção automática de performance do dispositivo
- Adaptação de efeitos baseada na capacidade
- Monitor de FPS em tempo real
- Respeito às preferências de acessibilidade

## 🛠️ Tecnologias

- **React 18** - Framework principal
- **Vite** - Build tool e dev server
- **Canvas API** - Efeitos visuais complexos
- **Web Audio API** - Sistema de áudio ambiente
- **CSS3** - Animações e efeitos visuais
- **Intersection Observer** - Otimizações de performance

## 📦 Instalação

```bash
# Clonar o repositório
git clone https://github.com/seu-usuario/memeternum-digital-grimoire.git

# Instalar dependências
cd memeternum-digital-grimoire
npm install

# Executar em desenvolvimento
npm run dev

# Build para produção
npm run build
```

## 🎯 Performance

### Níveis Adaptativos
- **High**: Todos os efeitos ativos (50 partículas, Matrix Rain, geometria)
- **Medium**: Efeitos reduzidos (25 partículas, sem partículas interativas)
- **Low**: Mínimo essencial (10 partículas, sem Matrix Rain)

### Otimizações
- Lazy loading de efeitos visuais
- Throttling de animações
- Detecção de dispositivos móveis
- Redução automática em conexões lentas

## 🎨 Personalização

### Cores
```css
:root {
  --void-black: #000000;
  --blood-red: #FF0033;
  --matrix-green: #00FF41;
  --alchemical-gold: #FFD700;
  --mystic-purple: #6600CC;
}
```

### Conteúdo
Edite as seções em `src/App.jsx`:
```javascript
const sections = {
  void: {
    title: '∅ VOID',
    content: 'Seu conteúdo personalizado...',
    symbol: '∅'
  }
}
```

## 📱 Compatibilidade

- ✅ Chrome/Edge 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Mobile (iOS/Android)
- ✅ Tablets

## 🔧 Estrutura do Projeto

```
src/
├── components/
│   ├── AdvancedEffects.jsx    # Efeitos visuais avançados
│   ├── AudioSystem.jsx        # Sistema de áudio ambiente
│   └── PerformanceOptimizer.jsx # Otimizações de performance
├── App.jsx                    # Componente principal
├── App.css                    # Estilos artísticos
└── main.jsx                   # Entry point
```

## 🎭 Filosofia de Design

*"Cada elemento carrega a tensão entre ordem e caos, entre o desejo de comunicar e a tendência do tédio de confundir. O site não apenas mostra quem você é, mas demonstra ativamente a luta interna entre criação e destruição."*

## 📄 Licença

Este projeto é uma obra de arte digital. Use com responsabilidade criativa.

---

**Desenvolvido com ❤️ e algoritmos místicos**

*Site ritualístico criado por Manus AI - 2025*

