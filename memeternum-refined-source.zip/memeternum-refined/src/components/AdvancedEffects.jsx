import { useEffect, useRef, useState } from 'react'

// Componente para partículas interativas
export const ParticleSystem = ({ mousePos, boredomLevel }) => {
  const canvasRef = useRef(null)
  const particlesRef = useRef([])
  
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    
    // Inicializar partículas
    const initParticles = () => {
      particlesRef.current = Array.from({ length: 50 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        opacity: Math.random() * 0.5 + 0.2,
        color: Math.random() > 0.5 ? '#00FF41' : '#FF0033'
      }))
    }
    
    initParticles()
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      particlesRef.current.forEach(particle => {
        // Atração ao mouse
        const dx = mousePos.x - particle.x
        const dy = mousePos.y - particle.y
        const distance = Math.sqrt(dx * dx + dy * dy)
        
        if (distance < 200) {
          particle.vx += dx * 0.0001
          particle.vy += dy * 0.0001
        }
        
        // Efeito do tédio
        particle.vx += (Math.random() - 0.5) * boredomLevel * 0.01
        particle.vy += (Math.random() - 0.5) * boredomLevel * 0.01
        
        // Movimento
        particle.x += particle.vx
        particle.y += particle.vy
        
        // Bordas
        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1
        
        // Desenhar
        ctx.fillStyle = particle.color
        ctx.globalAlpha = particle.opacity
        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fill()
        
        // Conexões
        particlesRef.current.forEach(other => {
          const dx2 = particle.x - other.x
          const dy2 = particle.y - other.y
          const distance2 = Math.sqrt(dx2 * dx2 + dy2 * dy2)
          
          if (distance2 < 100) {
            ctx.strokeStyle = particle.color
            ctx.globalAlpha = 0.1
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(particle.x, particle.y)
            ctx.lineTo(other.x, other.y)
            ctx.stroke()
          }
        })
      })
      
      requestAnimationFrame(animate)
    }
    
    animate()
  }, [mousePos, boredomLevel])
  
  return <canvas ref={canvasRef} className="particle-canvas" />
}

// Componente para texto que se fragmenta
export const FragmentedText = ({ text, isActive }) => {
  const [fragments, setFragments] = useState([])
  
  useEffect(() => {
    if (isActive) {
      const chars = text.split('')
      const newFragments = chars.map((char, i) => ({
        char,
        x: Math.random() * 20 - 10,
        y: Math.random() * 20 - 10,
        rotation: Math.random() * 360,
        opacity: Math.random() * 0.8 + 0.2,
        delay: i * 50
      }))
      setFragments(newFragments)
    } else {
      setFragments([])
    }
  }, [text, isActive])
  
  if (!isActive) return <span>{text}</span>
  
  return (
    <span className="fragmented-text">
      {fragments.map((fragment, i) => (
        <span
          key={i}
          className="text-fragment"
          style={{
            transform: `translate(${fragment.x}px, ${fragment.y}px) rotate(${fragment.rotation}deg)`,
            opacity: fragment.opacity,
            animationDelay: `${fragment.delay}ms`
          }}
        >
          {fragment.char}
        </span>
      ))}
    </span>
  )
}

// Componente para ondas de energia
export const EnergyWaves = ({ intensity }) => {
  return (
    <div className="energy-waves">
      {Array.from({ length: 5 }, (_, i) => (
        <div
          key={i}
          className="energy-wave"
          style={{
            animationDelay: `${i * 0.2}s`,
            animationDuration: `${2 - intensity * 0.1}s`,
            opacity: intensity * 0.1
          }}
        />
      ))}
    </div>
  )
}

// Componente para distorção de realidade
export const RealityDistortion = ({ active, children }) => {
  const [distortionLevel, setDistortionLevel] = useState(0)
  
  useEffect(() => {
    if (active) {
      const interval = setInterval(() => {
        setDistortionLevel(Math.random())
      }, 100)
      return () => clearInterval(interval)
    } else {
      setDistortionLevel(0)
    }
  }, [active])
  
  return (
    <div
      className="reality-distortion"
      style={{
        filter: active ? `hue-rotate(${distortionLevel * 360}deg) saturate(${1 + distortionLevel}) contrast(${1 + distortionLevel * 0.5})` : 'none',
        transform: active ? `scale(${1 + distortionLevel * 0.1}) skew(${distortionLevel * 2}deg)` : 'none'
      }}
    >
      {children}
    </div>
  )
}

// Componente para código Matrix
export const MatrixRain = ({ density = 0.5 }) => {
  const canvasRef = useRef(null)
  
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    
    const chars = '01∞Δψ⚡🜃◊∴∅⟡⧬αβγδεζηθικλμνξοπρστυφχψω'
    const fontSize = 14
    const columns = canvas.width / fontSize
    const drops = Array(Math.floor(columns)).fill(1)
    
    const draw = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      
      ctx.fillStyle = '#00FF41'
      ctx.font = `${fontSize}px monospace`
      
      for (let i = 0; i < drops.length; i++) {
        if (Math.random() < density) {
          const text = chars[Math.floor(Math.random() * chars.length)]
          ctx.fillText(text, i * fontSize, drops[i] * fontSize)
          
          if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
            drops[i] = 0
          }
          drops[i]++
        }
      }
    }
    
    const interval = setInterval(draw, 50)
    return () => clearInterval(interval)
  }, [density])
  
  return <canvas ref={canvasRef} className="matrix-rain" />
}

// Componente para geometria sagrada
export const SacredGeometry = ({ pattern = 'flower', size = 200, rotation = 0 }) => {
  const patterns = {
    flower: (
      <g>
        {Array.from({ length: 6 }, (_, i) => (
          <circle
            key={i}
            cx={Math.cos(i * Math.PI / 3) * 50}
            cy={Math.sin(i * Math.PI / 3) * 50}
            r="50"
            fill="none"
            stroke="currentColor"
            strokeWidth="1"
            opacity="0.3"
          />
        ))}
        <circle cx="0" cy="0" r="50" fill="none" stroke="currentColor" strokeWidth="2" />
      </g>
    ),
    merkaba: (
      <g>
        <polygon
          points="-50,-30 50,-30 0,-80"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
          opacity="0.5"
        />
        <polygon
          points="-50,30 50,30 0,80"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
          opacity="0.5"
        />
      </g>
    ),
    spiral: (
      <path
        d="M0,0 Q10,10 20,0 Q30,-20 50,0 Q70,30 100,0"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        opacity="0.4"
      />
    )
  }
  
  return (
    <div className="sacred-geometry">
      <svg
        width={size}
        height={size}
        viewBox="-100 -100 200 200"
        style={{ transform: `rotate(${rotation}deg)` }}
      >
        {patterns[pattern]}
      </svg>
    </div>
  )
}

