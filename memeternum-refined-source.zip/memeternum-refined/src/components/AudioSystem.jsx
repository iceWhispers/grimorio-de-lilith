import { useEffect, useRef, useState } from 'react'

// Sistema de áudio ambiente
export const AmbientAudio = ({ section, boredomLevel, isActive = false }) => {
  const audioContextRef = useRef(null)
  const oscillatorsRef = useRef([])
  const [isPlaying, setIsPlaying] = useState(false)
  
  useEffect(() => {
    if (!isActive) return
    
    // Criar contexto de áudio
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)()
    }
    
    const ctx = audioContextRef.current
    
    // Frequências base para cada seção
    const sectionFrequencies = {
      void: [55, 110, 165], // Frequências baixas e profundas
      loops: [220, 330, 440], // Frequências médias em loop
      chaos: [100, 200, 300, 400, 500], // Frequências caóticas
      mind: [432, 528, 741], // Frequências de cura/meditação
      glitch: [150, 300, 600, 1200] // Frequências distorcidas
    }
    
    const createAmbientSound = () => {
      // Limpar osciladores anteriores
      oscillatorsRef.current.forEach(osc => {
        try {
          osc.stop()
        } catch (e) {}
      })
      oscillatorsRef.current = []
      
      const frequencies = sectionFrequencies[section] || sectionFrequencies.void
      
      frequencies.forEach((freq, index) => {
        const oscillator = ctx.createOscillator()
        const gainNode = ctx.createGain()
        const filterNode = ctx.createBiquadFilter()
        
        // Configurar oscilador
        oscillator.type = section === 'glitch' ? 'sawtooth' : 'sine'
        oscillator.frequency.setValueAtTime(freq, ctx.currentTime)
        
        // Configurar filtro
        filterNode.type = 'lowpass'
        filterNode.frequency.setValueAtTime(freq * 2, ctx.currentTime)
        
        // Configurar ganho (volume muito baixo para ambiente)
        const baseVolume = 0.01
        const volume = baseVolume * (1 + boredomLevel * 0.1)
        gainNode.gain.setValueAtTime(volume, ctx.currentTime)
        
        // Conectar nós
        oscillator.connect(filterNode)
        filterNode.connect(gainNode)
        gainNode.connect(ctx.destination)
        
        // Adicionar modulação baseada no tédio
        if (boredomLevel > 5) {
          const lfo = ctx.createOscillator()
          const lfoGain = ctx.createGain()
          
          lfo.frequency.setValueAtTime(0.1 + boredomLevel * 0.05, ctx.currentTime)
          lfoGain.gain.setValueAtTime(freq * 0.1, ctx.currentTime)
          
          lfo.connect(lfoGain)
          lfoGain.connect(oscillator.frequency)
          
          lfo.start()
          oscillatorsRef.current.push(lfo)
        }
        
        oscillator.start()
        oscillatorsRef.current.push(oscillator)
      })
      
      setIsPlaying(true)
    }
    
    // Iniciar som ambiente após interação do usuário
    const startAudio = () => {
      if (ctx.state === 'suspended') {
        ctx.resume().then(() => {
          createAmbientSound()
        })
      } else {
        createAmbientSound()
      }
    }
    
    // Aguardar interação do usuário para iniciar áudio
    document.addEventListener('click', startAudio, { once: true })
    
    return () => {
      oscillatorsRef.current.forEach(osc => {
        try {
          osc.stop()
        } catch (e) {}
      })
      document.removeEventListener('click', startAudio)
    }
  }, [section, boredomLevel, isActive])
  
  return null // Componente invisível
}

// Gerador de sons de glitch
export const GlitchSounds = ({ active }) => {
  const audioContextRef = useRef(null)
  
  useEffect(() => {
    if (!active) return
    
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)()
    }
    
    const ctx = audioContextRef.current
    
    const createGlitchSound = () => {
      const oscillator = ctx.createOscillator()
      const gainNode = ctx.createGain()
      const filterNode = ctx.createBiquadFilter()
      
      // Frequência aleatória para glitch
      const freq = 100 + Math.random() * 500
      oscillator.frequency.setValueAtTime(freq, ctx.currentTime)
      oscillator.type = Math.random() > 0.5 ? 'square' : 'sawtooth'
      
      // Filtro com cutoff aleatório
      filterNode.type = 'bandpass'
      filterNode.frequency.setValueAtTime(freq * (0.5 + Math.random()), ctx.currentTime)
      filterNode.Q.setValueAtTime(10 + Math.random() * 20, ctx.currentTime)
      
      // Volume baixo e envelope rápido
      gainNode.gain.setValueAtTime(0, ctx.currentTime)
      gainNode.gain.linearRampToValueAtTime(0.02, ctx.currentTime + 0.01)
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1)
      
      oscillator.connect(filterNode)
      filterNode.connect(gainNode)
      gainNode.connect(ctx.destination)
      
      oscillator.start(ctx.currentTime)
      oscillator.stop(ctx.currentTime + 0.1)
    }
    
    // Criar múltiplos sons de glitch
    const glitchInterval = setInterval(() => {
      if (Math.random() > 0.7) { // 30% chance a cada intervalo
        createGlitchSound()
      }
    }, 100)
    
    return () => clearInterval(glitchInterval)
  }, [active])
  
  return null
}

// Controle de áudio
export const AudioControls = ({ onToggle, isEnabled }) => {
  return (
    <div className="audio-controls">
      <button
        className="audio-toggle"
        onClick={onToggle}
        title={isEnabled ? 'Desativar áudio' : 'Ativar áudio'}
      >
        {isEnabled ? '🔊' : '🔇'}
      </button>
    </div>
  )
}

