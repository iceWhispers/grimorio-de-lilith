import { useEffect, useState, useCallback, useRef } from 'react'

// Hook para detectar performance do dispositivo
export const usePerformanceDetection = () => {
  const [performanceLevel, setPerformanceLevel] = useState('high')
  
  useEffect(() => {
    const detectPerformance = () => {
      // Detectar baseado em características do dispositivo
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
      const hasLowMemory = navigator.deviceMemory && navigator.deviceMemory < 4
      const hasSlowConnection = navigator.connection && navigator.connection.effectiveType === 'slow-2g'
      
      // Teste de performance simples
      const start = performance.now()
      for (let i = 0; i < 100000; i++) {
        Math.random()
      }
      const end = performance.now()
      const executionTime = end - start
      
      if (isMobile || hasLowMemory || hasSlowConnection || executionTime > 10) {
        setPerformanceLevel('low')
      } else if (executionTime > 5) {
        setPerformanceLevel('medium')
      } else {
        setPerformanceLevel('high')
      }
    }
    
    detectPerformance()
  }, [])
  
  return performanceLevel
}

// Componente para configurações adaptativas
export const AdaptiveSettings = ({ performanceLevel, children }) => {
  const settings = {
    low: {
      particleCount: 10,
      animationDuration: 2000,
      enableMatrix: false,
      enableParticles: false,
      enableGeometry: false,
      maxFloatingNumbers: 5
    },
    medium: {
      particleCount: 25,
      animationDuration: 1500,
      enableMatrix: true,
      enableParticles: false,
      enableGeometry: true,
      maxFloatingNumbers: 10
    },
    high: {
      particleCount: 50,
      animationDuration: 1000,
      enableMatrix: true,
      enableParticles: true,
      enableGeometry: true,
      maxFloatingNumbers: 20
    }
  }
  
  const currentSettings = settings[performanceLevel]
  
  return (
    <div 
      className={`adaptive-container performance-${performanceLevel}`}
      data-performance={performanceLevel}
    >
      {typeof children === 'function' ? children(currentSettings) : children}
    </div>
  )
}

// Hook para throttling de animações
export const useAnimationThrottle = (callback, delay = 16) => {
  const [isThrottled, setIsThrottled] = useState(false)
  
  const throttledCallback = useCallback((...args) => {
    if (!isThrottled) {
      callback(...args)
      setIsThrottled(true)
      setTimeout(() => setIsThrottled(false), delay)
    }
  }, [callback, delay, isThrottled])
  
  return throttledCallback
}

// Componente para lazy loading de efeitos
export const LazyEffect = ({ children, threshold = 0.1, fallback = null }) => {
  const [isVisible, setIsVisible] = useState(false)
  const [element, setElement] = useState(null)
  
  useEffect(() => {
    if (!element) return
    
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting)
      },
      { threshold }
    )
    
    observer.observe(element)
    
    return () => observer.disconnect()
  }, [element, threshold])
  
  return (
    <div ref={setElement}>
      {isVisible ? children : fallback}
    </div>
  )
}

// Monitor de FPS
export const FPSMonitor = ({ onFPSChange }) => {
  const [fps, setFPS] = useState(60)
  const frameCountRef = useRef(0)
  const lastTimeRef = useRef(performance.now())
  
  useEffect(() => {
    const measureFPS = () => {
      frameCountRef.current++
      const currentTime = performance.now()
      
      if (currentTime - lastTimeRef.current >= 1000) {
        const currentFPS = Math.round((frameCountRef.current * 1000) / (currentTime - lastTimeRef.current))
        setFPS(currentFPS)
        onFPSChange?.(currentFPS)
        
        frameCountRef.current = 0
        lastTimeRef.current = currentTime
      }
      
      requestAnimationFrame(measureFPS)
    }
    
    const animationId = requestAnimationFrame(measureFPS)
    return () => cancelAnimationFrame(animationId)
  }, [onFPSChange])
  
  return (
    <div className="fps-monitor">
      <span className="fps-label">FPS:</span>
      <span className={`fps-value ${fps < 30 ? 'fps-low' : fps < 50 ? 'fps-medium' : 'fps-high'}`}>
        {fps}
      </span>
    </div>
  )
}

// Componente para redução de movimento
export const MotionReducer = ({ children, respectPreferences = true }) => {
  const [reduceMotion, setReduceMotion] = useState(false)
  
  useEffect(() => {
    if (respectPreferences) {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)')
      setReduceMotion(mediaQuery.matches)
      
      const handleChange = (e) => setReduceMotion(e.matches)
      mediaQuery.addEventListener('change', handleChange)
      
      return () => mediaQuery.removeEventListener('change', handleChange)
    }
  }, [respectPreferences])
  
  return (
    <div className={`motion-container ${reduceMotion ? 'reduced-motion' : ''}`}>
      {children}
    </div>
  )
}

