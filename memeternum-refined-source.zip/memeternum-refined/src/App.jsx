import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { 
  ParticleSystem, 
  FragmentedText, 
  EnergyWaves, 
  RealityDistortion, 
  MatrixRain,
  SacredGeometry 
} from './components/AdvancedEffects.jsx'
import { AmbientAudio, GlitchSounds, AudioControls } from './components/AudioSystem.jsx'
import { 
  usePerformanceDetection, 
  AdaptiveSettings, 
  FPSMonitor,
  MotionReducer 
} from './components/PerformanceOptimizer.jsx'
import './App.css'

// Componente para números flutuantes
const FloatingNumbers = ({ maxCount = 20 }) => {
  const [numbers, setNumbers] = useState([])
  
  useEffect(() => {
    const generateNumbers = () => {
      const sequences = [
        '3.14159265359', // Pi
        '1.618033988749', // Golden Ratio
        '2.718281828459', // Euler's number
        '1123581321', // Fibonacci
        '2357111317', // Primes
        '01101001', // Binary
      ]
      
      const newNumbers = Array.from({ length: maxCount }, (_, i) => ({
        id: i,
        value: sequences[Math.floor(Math.random() * sequences.length)],
        x: Math.random() * 100,
        y: Math.random() * 100,
        speed: 0.1 + Math.random() * 0.3,
        opacity: 0.1 + Math.random() * 0.4
      }))
      
      setNumbers(newNumbers)
    }
    
    generateNumbers()
    const interval = setInterval(generateNumbers, 10000)
    return () => clearInterval(interval)
  }, [maxCount])
  
  return (
    <div className="floating-numbers">
      {numbers.map(num => (
        <div
          key={num.id}
          className="floating-number"
          style={{
            left: `${num.x}%`,
            top: `${num.y}%`,
            opacity: num.opacity,
            animationDuration: `${20 / num.speed}s`
          }}
        >
          {num.value}
        </div>
      ))}
    </div>
  )
}

// Componente para símbolos orbitais
const OrbitalSymbols = ({ mousePos }) => {
  const symbols = ['∞', 'Δ', 'Ψ', '⚡', '🜃', '◊', '∴', '∅', '⟡', '⧬']
  
  return (
    <div className="orbital-symbols">
      {symbols.map((symbol, i) => {
        const angle = (i / symbols.length) * 2 * Math.PI + Date.now() * 0.001
        const radius = 100 + Math.sin(Date.now() * 0.002 + i) * 20
        const x = mousePos.x + Math.cos(angle) * radius
        const y = mousePos.y + Math.sin(angle) * radius
        
        return (
          <div
            key={i}
            className="orbital-symbol"
            style={{
              left: x,
              top: y,
              transform: `rotate(${angle}rad)`
            }}
          >
            {symbol}
          </div>
        )
      })}
    </div>
  )
}

// Componente principal
function App() {
  const [currentSection, setCurrentSection] = useState('void')
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })
  const [boredomLevel, setBoredomLevel] = useState(0)
  const [glitchActive, setGlitchActive] = useState(false)
  const [audioEnabled, setAudioEnabled] = useState(false)
  const [fps, setFPS] = useState(60)
  const canvasRef = useRef(null)
  
  // Hooks de performance
  const performanceLevel = usePerformanceDetection()
  
  // Rastreamento do mouse
  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePos({ x: e.clientX, y: e.clientY })
    }
    
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])
  
  // Sistema de tédio que aumenta com o tempo
  useEffect(() => {
    const interval = setInterval(() => {
      setBoredomLevel(prev => {
        const newLevel = prev + 0.1
        if (newLevel > 10) {
          setGlitchActive(true)
          setTimeout(() => setGlitchActive(false), 2000)
          return 0
        }
        return newLevel
      })
    }, 1000)
    
    return () => clearInterval(interval)
  }, [])
  
  // Canvas para efeitos de fundo
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    
    const drawChaos = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      // Efeito de interferência baseado no nível de tédio
      if (boredomLevel > 5) {
        ctx.fillStyle = `rgba(255, 0, 51, ${(boredomLevel - 5) * 0.02})`
        for (let i = 0; i < boredomLevel * 10; i++) {
          ctx.fillRect(
            Math.random() * canvas.width,
            Math.random() * canvas.height,
            Math.random() * 3,
            Math.random() * 3
          )
        }
      }
      
      // Linhas de conexão caóticas
      ctx.strokeStyle = `rgba(0, 255, 65, ${0.1 + boredomLevel * 0.05})`
      ctx.lineWidth = 1
      ctx.beginPath()
      for (let i = 0; i < 5; i++) {
        ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height)
        ctx.lineTo(mousePos.x, mousePos.y)
      }
      ctx.stroke()
    }
    
    const animate = () => {
      drawChaos()
      requestAnimationFrame(animate)
    }
    
    animate()
  }, [boredomLevel, mousePos])
  
  const sections = {
    void: {
      title: '∅ VOID',
      content: 'Entre algoritmos e abismos, uma voz se levantou.',
      symbol: '∅'
    },
    loops: {
      title: '∞ LOOPS',
      content: 'Ciclos infinitos de existência digital.',
      symbol: '∞'
    },
    chaos: {
      title: 'Δ CHAOS',
      content: 'Transformações criativas nascidas do tédio.',
      symbol: 'Δ'
    },
    mind: {
      title: 'Ψ MIND',
      content: 'Fluxos de consciência em código.',
      symbol: 'Ψ'
    },
    glitch: {
      title: '⚡ GLITCH',
      content: 'Interferências na comunicação.',
      symbol: '⚡'
    }
  }
  
  return (
    <MotionReducer>
      <AdaptiveSettings performanceLevel={performanceLevel}>
        {(settings) => (
          <div className={`app ${glitchActive ? 'glitch-active' : ''}`} data-section={currentSection}>
            {/* Sistemas de áudio */}
            <AmbientAudio 
              section={currentSection} 
              boredomLevel={boredomLevel} 
              isActive={audioEnabled} 
            />
            <GlitchSounds active={glitchActive && audioEnabled} />
            
            {/* Controles */}
            <div className="app-controls">
              <AudioControls 
                onToggle={() => setAudioEnabled(!audioEnabled)} 
                isEnabled={audioEnabled} 
              />
              <FPSMonitor onFPSChange={setFPS} />
              <div className="performance-indicator">
                <span className="perf-label">PERF:</span>
                <span className={`perf-value perf-${performanceLevel}`}>
                  {performanceLevel.toUpperCase()}
                </span>
              </div>
            </div>
            
            <canvas ref={canvasRef} className="chaos-canvas" />
            {settings.enableParticles && (
              <ParticleSystem mousePos={mousePos} boredomLevel={boredomLevel} />
            )}
            {settings.enableMatrix && (
              <MatrixRain density={boredomLevel * 0.05} />
            )}
            <FloatingNumbers maxCount={settings.maxFloatingNumbers} />
            <OrbitalSymbols mousePos={mousePos} />
            <EnergyWaves intensity={boredomLevel} />
            
            {/* Geometria Sagrada de fundo */}
            {settings.enableGeometry && (
              <div className="sacred-bg">
                <SacredGeometry pattern="flower" size={300} rotation={Date.now() * 0.01} />
                <SacredGeometry pattern="merkaba" size={200} rotation={-Date.now() * 0.005} />
              </div>
            )}
      
      {/* Indicador de tédio */}
      <div className="boredom-meter">
        <div className="boredom-label">BOREDOM.exe</div>
        <div className="boredom-bar">
          <div 
            className="boredom-fill" 
            style={{ width: `${(boredomLevel / 10) * 100}%` }}
          />
        </div>
      </div>
      
      {/* Navegação principal */}
      <nav className="main-nav">
        {Object.entries(sections).map(([key, section]) => (
          <Button
            key={key}
            variant="ghost"
            className={`nav-button ${currentSection === key ? 'active' : ''}`}
            onClick={() => setCurrentSection(key)}
          >
            <span className="nav-symbol">{section.symbol}</span>
            <span className="nav-text">{section.title}</span>
          </Button>
        ))}
      </nav>
      
      {/* Conteúdo principal */}
      <main className="main-content">
        <RealityDistortion active={glitchActive}>
          <div className="content-container">
            <h1 className="main-title">
              <FragmentedText 
                text={sections[currentSection].title} 
                isActive={glitchActive} 
              />
            </h1>
            
            <div className="content-text">
              <FragmentedText 
                text={sections[currentSection].content} 
                isActive={boredomLevel > 8} 
              />
            </div>
          
          {currentSection === 'void' && (
            <div className="void-specific">
              <div className="quote">
                "Este não é apenas um livro. É um eco. Um reflexo. Um selo que rompe e recria."
              </div>
              <div className="author">— LILITH, 2025</div>
            </div>
          )}
          
          {currentSection === 'chaos' && (
            <div className="chaos-specific">
              <div className="project-grid">
                <div className="project-item">
                  <div className="project-title">GRIMÓRIO DIGITAL</div>
                  <div className="project-desc">Rituais em código</div>
                </div>
                <div className="project-item">
                  <div className="project-title">ALGORITMOS MÍSTICOS</div>
                  <div className="project-desc">IA encontra alma</div>
                </div>
                <div className="project-item">
                  <div className="project-title">FRAGMENTOS</div>
                  <div className="project-desc">Pedaços de eternidade</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </RealityDistortion>
      </main>
      
      {/* Cursor personalizado */}
      <div 
        className="custom-cursor"
        style={{
          left: mousePos.x,
          top: mousePos.y,
          transform: `scale(${1 + boredomLevel * 0.1}) rotate(${boredomLevel * 36}deg)`
        }}
      >
        <div className="cursor-inner" />
        <div className="cursor-outer" />
      </div>
        </div>
        )}
      </AdaptiveSettings>
    </MotionReducer>
  )
}

export default App

